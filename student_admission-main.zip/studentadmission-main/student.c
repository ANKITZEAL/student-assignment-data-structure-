#include <string.h>
#include "../Headers/student.h"
#include <assert.h>
#include <stdio.h>


Program program_seats(int8_t bda, int8_t ml, int8_t es){
    Program prog = {bda, ml, es, 0, 0, 0};
    return prog;
}


